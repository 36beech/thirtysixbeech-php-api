<?php

return array(
  'db' => array(
    'host'    => 'database',
    'port'    => 3306,
    'dbname'  => 'birds',
    'user'    => 'lamp',
    'pass'    => 'lamp',
    'charset' => 'utf8mb4',
  ),
  //echo password_hash('123456', PASSWORD_BCRYPT, ['cost' => 12]);"
  'auth' => array(
    'pin_hash'       => '$2y$12$Uojqg0/IU0JaGrm3MYe0OeG3zWcQTXpSMHNdV9JkLNaFXMWjm9L2G',
    'token_secret'   => 'zash17ZYl1cA93iypRVPA0tLrI+uZbPVTvIh7DG8Pq0=',
    'token_ttl'      => 3600, // seconds
  ),
);
